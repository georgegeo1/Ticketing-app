<?php 
	include($_SERVER['DOCUMENT_ROOT'].'/ecommerce/includes/variables.php'); 
	$connect->set_charset('utf8');
	
?>