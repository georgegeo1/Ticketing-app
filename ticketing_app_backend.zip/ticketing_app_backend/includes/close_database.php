<?php
	include($_SERVER['DOCUMENT_ROOT'].'/ecommerce/includes/variables.php');
	$connect->close();
?>