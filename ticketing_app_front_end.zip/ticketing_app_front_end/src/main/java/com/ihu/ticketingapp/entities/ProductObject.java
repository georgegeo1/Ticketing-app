package com.ihu.ticketingapp.entities;


public class ProductObject {

    private int productId;

    private String productName;

    private int productImage;

    private String productDescription;

    private double productPrice;

    private int productBarcode;

    private String productSeat;

    public ProductObject(int productId, String productName, int productImage, String productDescription, double productPrice, int productBarcode, String productSeat) {
        this.productId = productId;
        this.productName = productName;
        this.productImage = productImage;
        this.productDescription = productDescription;
        this.productPrice = productPrice;
        this.productBarcode = productBarcode;
        this.productSeat = productSeat;
    }

    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public int getProductImage() {
        return productImage;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public int getProductBarcode() {
        return productBarcode;
    }

    public String getProductSeat() {
        return productSeat;
    }

    @Override
    public String toString() {
        return "Product id and name: " + productId + " " + productName;
    }
}
