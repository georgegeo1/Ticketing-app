package com.ihu.ticketingapp;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.ihu.ticketingapp.adapters.ShopRecyclerViewAdapter;
import com.ihu.ticketingapp.entities.ProductObject;
import com.ihu.ticketingapp.helpers.SpacesItemDecoration;

import java.util.ArrayList;
import java.util.List;

public class ShoppingActivity extends AppCompatActivity {

    private static final String TAG = ShoppingActivity.class.getSimpleName();

    private RecyclerView shoppingRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        shoppingRecyclerView = (RecyclerView)findViewById(R.id.product_list);
        GridLayoutManager mGrid = new GridLayoutManager(ShoppingActivity.this, 2);
        shoppingRecyclerView.setLayoutManager(mGrid);
        shoppingRecyclerView.setHasFixedSize(true);
        shoppingRecyclerView.addItemDecoration(new SpacesItemDecoration(2, 12, false));

        ShopRecyclerViewAdapter shopAdapter = new ShopRecyclerViewAdapter(ShoppingActivity.this, getAllProductsOnSale());
        shoppingRecyclerView.setAdapter(shopAdapter);
    }


    private List<ProductObject> getAllProductsOnSale(){
        List<ProductObject> products = new ArrayList<ProductObject>();
        products.add(new ProductObject(1, "Ticket 1", R.drawable.productonesmall, "Chicago Bulls VS Boston Celtics game last minute ticket", 110, 745011, "121"));
        products.add(new ProductObject(1, "Ticket 2", R.drawable.producttwo, "Chicago Bulls VS Boston Celtics game last minute ticket", 90, 620052, "271"));
        products.add(new ProductObject(1, "Ticket 3", R.drawable.productthree, "Chicago Bulls VS Boston Celtics game last minute ticket", 130, 441074, "65"));
        products.add(new ProductObject(1, "Ticket 4", R.drawable.productfour, "Chicago Bulls VS Boston Celtics game last minute ticket", 110, 663266, "428"));
        products.add(new ProductObject(1, "Ticket 5", R.drawable.productfive, "Chicago Bulls VS Boston Celtics game last minute ticket", 80, 960045, "163"));
        products.add(new ProductObject(1, "Ticket 6", R.drawable.productsix, "Chicago Bulls VS Boston Celtics game last minute ticket", 190, 320852, "57"));
        return products;
    }
}
