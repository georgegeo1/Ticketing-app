package com.ihu.ticketingapp.jsonEntityObjects;

public class ServerObject {

    private String success;

    public ServerObject(String success) {
        this.success = success;
    }

    public String getSuccess() {
        return success;
    }
}


